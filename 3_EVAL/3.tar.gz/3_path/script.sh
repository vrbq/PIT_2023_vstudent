#!/bin/bash

# Définir le mot de passe encodé en base64
mot_de_passe_encode="c3RhcndhcnM="  # Remplacez ceci par le mot de passe encodé en base64

# Divise la variable PATH en une liste de chemins séparés par ':'
IFS=":" read -ra chemins <<< "$PATH"

# Définir une variable pour indiquer si un chemin contenant "pit" a été trouvé
chemin_contenant_pit_trouve=0

# Boucle à travers chaque chemin dans la liste
for chemin in "${chemins[@]}"; do
    # Vérifie si le chemin actuel contient le mot clé "pit"
    if [[ "$chemin" == *pit* ]]; then
        chemin_contenant_pit_trouve=1
        break
    fi
done

# Si un chemin contenant "pit" a été trouvé, décode et affiche le mot de passe
if [ $chemin_contenant_pit_trouve -eq 1 ]; then
    mot_de_passe=$(echo "$mot_de_passe_encode" | base64 --decode)
    echo "Un chemin contenant 'pit' a été trouvé dans la variable PATH."
    echo "Mot de passe : $mot_de_passe"
else
    echo "Aucun chemin contenant 'pit' n'a été trouvé dans la variable PATH."
fi

