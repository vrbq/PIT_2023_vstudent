#!/bin/bash

# Vérifier si le fichier "resultat" existe
if [ ! -e "resultat" ]; then
    echo "Le fichier 'resultat' n'existe pas dans le dossier courant."
    exit 1
fi

# Variable pour garder une trace des erreurs
errors=0

for ((i=1; i<=500; i++)); do
    # Lire le contenu du fichier "resultat" à la ligne correspondant au nombre i
    line=$(sed -n "${i}p" resultat)

    # Supprimer les espaces en début et en fin de ligne
    line_trimmed="$(echo -e "${line}" | tr -d '[:space:]')"

    # Vérifier si le nombre est un multiple de 3
    if ((i % 3 == 0)); then
        if [ "$line_trimmed" != "3" ]; then
            errors=$((errors + 1))
        fi
    else
        # Calculer la somme des chiffres du nombre
        sum=0
        num=$i
        while [ $num -gt 0 ]; do
            digit=$((num % 10))
            sum=$((sum + digit))
            num=$((num / 10))
        done

        # Si la somme des chiffres est égale à 10, vérifier si le fichier contient "10"
        if [ $sum -eq 10 ]; then
            if [ "$line_trimmed" != "10" ]; then
                errors=$((errors + 1))
            fi
        else
            if [ "$line_trimmed" != "$i" ]; then
                errors=$((errors + 1))
            fi
        fi
    fi
done

if [ $errors -eq 0 ]; then
 # Mot de passe encodé en base64
    password_encoded="ZGFrb3Rh"

    # Décodez le mot de passe et affichez-le à l'utilisateur
    password_decoded=$(echo -n "$password_encoded" | base64 --decode)
    echo "Le fichier 'resultat' respecte les règles pour les nombres de 1 à 500."
    echo "Good job ! Le mot de passe : $password_decoded"


else
    echo "Le fichier 'resultat' ne respecte pas les règles pour les nombres de 1 à 500. Il y a $errors erreur(s)."
fi

