#!/bin/bash

# Vérifier la présence du fichier
if [ -e "SuperTux-v0.6.3.glibc2.29-x86_64.AppImage" ]; then
    # Obtenir la taille en Méga du fichier en utilisant 'du -h'
    taille=$(du -h "SuperTux-v0.6.3.glibc2.29-x86_64.AppImage" | cut -f1 | sed 's/M//')
    
    # Demander à l'utilisateur la taille en Méga du fichier
    read -p "Quelle est la taille en Méga du fichier 'SuperTux-v0.6.3.glibc2.29-x86_64.AppImage'? " reponse
    
    # Supprimer la lettre 'M' de la réponse de l'utilisateur (si présente)
    reponse="${reponse/M/}"   
 
    # Vérifier si la réponse est correcte
    if [ "$reponse" = "$taille" ]; then
        # Stocker la phrase encodée en base 64
        mot_de_passe_encrypted="QnJhdm8gISBWb2ljaSBsZSBtb3QgZGUgcGFzc2UgOiAnc3VtbWVyJw=="
        
        # Décoder et afficher le mot de passe
        mot_de_passe=$(echo "$mot_de_passe_encrypted" | base64 -d)
        echo "$mot_de_passe"
    else
        echo "Ce n'est pas la bonne réponse."
    fi
else
    echo "Le fichier 'SuperTux-v0.6.3.glibc2.29-x86_64.AppImage' n'est pas présent."
fi

