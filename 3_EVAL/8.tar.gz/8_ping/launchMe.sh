#!/bin/bash

# Chaîne de vérification encodée en base64
chaine_verification_base64="MTM0LjIxNC4xODIu"

# Demande à l'utilisateur de saisir une chaîne de caractères
read -p "Donnez une adresse IP appartenant au domaine insa-lyon.fr : " adresse_ip

# Décode la chaîne de vérification
chaine_verification=$(echo $chaine_verification_base64 | base64 --decode)

# Vérifie si l'adresse IP contient la chaîne de vérification
if [[ $adresse_ip == *$chaine_verification* ]]; then
    # Mot de passe encodé en base64
    mot_de_passe_base64="cmljYXJkbw=="
    # Décode le mot de passe
    mot_de_passe=$(echo $mot_de_passe_base64 | base64 --decode)
    echo "Bravo ! Le mot de passe est : $mot_de_passe"
else
    echo "Adresse IP n'appartenant pas au domaine de l'insa"
fi

