#!/bin/bash

# Vérifier si Java est installé
if ! command -v java &> /dev/null; then
    echo "Java n'est pas installé sur votre machine."
    exit 1
fi

# Obtenir la version de Java installée
java_version=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')

# Demander à l'utilisateur la version de Java installée
read -p "Quelle est la version de Java installée sur votre machine ? " user_input

# Vérifier si la réponse utilisateur est correcte
if [ "$user_input" == "$java_version" ]; then
    encoded_password="QnJhdm8gISBWb2ljaSBsZSBtb3QgZGUgcGFzc2UgOiBoYW1tZXI="
    decoded_password=$(echo "$encoded_password" | base64 -d)
    echo "$decoded_password"
else
    echo "Ce n'est pas la bonne réponse."
fi

