#!/bin/bash

echo "Un programme mystere vient d'etre lancé ..."

echo "Veuillez répondre aux deux questions dans test_1 et test_2 pour avoir le mot de passe complet."
echo "test_1 vous donnera la première moitié, test_2 la seconde"
echo "Le mot de passe complet sera les deux moitié réunies, collées l'une à l'autre"

# Fonction pour afficher le timer
display_timer() {
    local remaining_time=$1
}


# Durée du timer en secondes
timer_max=14400

# Boucle du compte à rebours
for ((remaining_time = 0; remaining_time < timer_max; remaining_time++)); do
    display_timer $remaining_time
    sleep 1
done
