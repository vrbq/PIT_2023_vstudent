#!/bin/bash

# Étape 1: Récupérer le PID du processus mystery.sh
pid=$(ps aux | grep mystery.sh | grep -v grep | awk '{print $2}')
echo $pid

# Étape 2: Stocker le PID dans une variable
if [ -z "$pid" ]; then
    echo "Le processus mystery.sh n'est pas en cours d'exécution."
    exit 1
fi

# Étape 3: Demander à l'utilisateur le PID du processus mystery
read -p "Quel est le pid du processus mystery ? " user_pid

# Étape 4: Vérifier la réponse de l'utilisateur
if [ "$user_pid" == "$pid" ]; then
    # La première moitié du mot de passe encodée en base64
    encoded_password="c3Rhcg=="

    # Décoder le mot de passe en base64
    decoded_password=$(echo "$encoded_password" | base64 -d)

    echo "Bravo ! La première moitié du mot de passe est : $decoded_password"
else
    echo "Ce n'est pas le bon PID."
fi

