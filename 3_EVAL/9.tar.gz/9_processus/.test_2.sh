#!/bin/bash

etat=$(ps aux | grep mystery.sh | awk '{print $8}')

if [[ "$etat" =~ "T" ]]; then    
# Décode la deuxième moitié du mot de passe depuis base64
    mot_de_passe=$(echo "Y3JhZnQ=" | base64 -d)
    echo "Bravo ! La seconde moitié du mot de passe est : $mot_de_passe"
else
    echo "Met en pause le processus mystery"
fi

