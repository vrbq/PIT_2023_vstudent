#!/bin/bash

mv .test_1.sh test_1.sh
mv .test_2.sh test_2.sh

chmod +x .mystery.sh
./.mystery.sh  > instructions 2>&1 & 

