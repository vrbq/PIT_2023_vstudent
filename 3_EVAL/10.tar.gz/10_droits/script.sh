#!/bin/bash

# Nom de l'utilisateur à créer
nouvel_utilisateur="noob"

# Vérifier si l'utilisateur existe déjà
if ! id "$nouvel_utilisateur" &>/dev/null; then
        sudo useradd "$nouvel_utilisateur"
fi

# Encodage en base64
encoded_phrase="QmllbiBqb3XDqSAhIExlIG1vdCBkZSBwYXNzZSBlc3QgOiBtYXRyaXg="

# Écrire la phrase décodée dans un fichier
echo "$encoded_phrase" | base64 -d > passwordIsHere

# Changer le propriétaire et le groupe du fichier "passwordIsHere" vers "noob"
sudo chown noob:noob passwordIsHere

# Enlever toutes les permissions sur le fichier "passwordIsHere"
sudo chmod 000 passwordIsHere
