#!/bin/bash

# Chaîne de caractères de vérification encodée en Base64
encoded_verification="c2F0ZWxsaXRlL2FudGVubmEvZGF0YQ=="

# Décoder la chaîne de vérification à partir de Base64
decoded_verification=$(echo "$encoded_verification" | base64 -d)

# Demander à l'utilisateur de saisir une chaîne de caractères
read -p "Quel est le chemin relatif (depuis ce dossier) au fichier "shiny_unicorn" : " input_string

# Vérifier si la chaîne de caractères est égale à la chaîne de vérification décodée
if [[ "$input_string" == *"$decoded_verification"* ]]; then
    # Le mot de passe encodé en Base64
    encoded_password=""ZGluZ2Rvbmc=  # Vous pouvez changer cette valeur si nécessaire

    # Décoder le mot de passe à partir de Base64
    decoded_password=$(echo "$encoded_password" | base64 -d)

    echo "Bravo ! Le mot de passe est : $decoded_password"
else
    echo "Ce n'est pas le bon chemin"
fi

