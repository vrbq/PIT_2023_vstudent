#!/bin/bash

# Récupérer la sortie de la commande "df" et la stocker dans une variable
df_output=$(df)

# Ignorer la première ligne (en-tête) en utilisant "tail -n +2"
# Trier les lignes en fonction de l'espace disque disponible (colonne 4) en ordre décroissant (-r)
# Sélectionner la première ligne (celle avec le plus d'espace disque disponible) en utilisant "head -n 1"
most_available_fs=$(echo "$df_output" | tail -n +2 | sort -k4 -nr | head -n 1)

# Extraire le point de montage ("Monté sur") (colonne 6) à partir de la ligne trouvée
mounted_on=$(echo "$most_available_fs" | awk '{print $6}')

# Demander à l'utilisateur de deviner le point de montage
read -p "Devinez le point de montage correspondant au système de fichiers avec le plus d'espace disque disponible : " user_guess

# Définir le mot de passe encodé en Base64
encoded_password="YXdlc29tZQ=="

# Vérifier si la réponse de l'utilisateur est correcte
if [ "$user_guess" = "$mounted_on" ]; then
    echo "Bravo ! Votre réponse est correcte. Le mot de passe est :"
    echo "$(echo "$encoded_password" | base64 --decode)"
else
    echo "Désolé, votre réponse est incorrecte."
fi

